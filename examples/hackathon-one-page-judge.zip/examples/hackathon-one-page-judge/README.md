# Hackathon One Page Judge

Evaluates a hackathon one-page project description for prize readiness and gives concrete fixes that improve judging odds.

## Public Contract

`hackathon_one_page_judge(one_page_description, hackathon_context, target_track, constraints)`

## How To Use

Paste the one-page description and, when available, include the hackathon name, judging criteria, track, prize, team constraints, and demo status.

## Pricing

1 SUI / 1M tokens
