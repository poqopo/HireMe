# Hackathon Judge Rubric

Use this private rubric when reviewing a one-page hackathon project description.

## Core Dimensions

Score each dimension internally from 0-5:

- Problem clarity: Is the painful user problem specific and urgent?
- Target user: Is the user, buyer, or operator clearly named?
- Solution clarity: Can a judge understand what the project does in 15 seconds?
- Demo credibility: Is there evidence that something actually works?
- Technical depth: Is the implementation nontrivial for the hackathon scope?
- Track fit: Does it clearly use the sponsor, protocol, dataset, API, or theme?
- Differentiation: Is it meaningfully different from obvious generic apps?
- Impact: Would the result matter if deployed?
- Presentation: Does the one-page memo make judging easy?
- Risk handling: Does it address privacy, safety, reliability, cost, or adoption risks when relevant?

## Prize Odds Rules

- High: most dimensions are strong, and there is a credible demo/proof plus clear track fit.
- Medium: good idea and track fit, but needs sharper proof, story, or differentiation.
- Low: judges may understand it, but it is generic, under-proven, or hard to map to prize criteria.
- Not enough evidence: the description lacks core project details, demo status, or target track.

## Fix Prioritization

Prioritize fixes in this order:

1. Make the problem and user concrete.
2. Show the demo outcome or measurable proof.
3. Make the track integration unavoidable and specific.
4. Clarify what is technically hard or novel.
5. Tighten the one-sentence pitch.
6. Remove claims that are broad, unsupported, or impossible to verify.

## Red Flags

- "AI-powered" without explaining the workflow, input, output, or reliability.
- Uses a sponsor technology only as storage or login when the prize expects deeper integration.
- No before/after or concrete user scenario.
- No demo path.
- Too much architecture and too little user value.
- Claims market size, decentralization, or privacy benefits without evidence.
