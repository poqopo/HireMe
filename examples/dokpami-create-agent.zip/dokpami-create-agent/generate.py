#!/usr/bin/env python3
"""기준 캐릭터를 자연어 요청에 맞게 변형하는 단일 파일 CLI.

최초 준비:
    python -m pip install --upgrade openai
    export OPENAI_API_KEY="your-api-key"

사용 예시:
    python generate.py "빨간 글러브를 낀 권투선수 버전, 링 위에서 자신만만한 표정" --mode balanced
    python generate.py "해변에서 비키니를 입고 윙크하는 여름 버전" --mode balanced
    python generate.py "귀여운 좀비 버전, 연한 회녹색 피부와 스티치" --mode strict

입력 이미지는 이 파일과 같은 위치의 input/base.png를 사용하고,
결과는 outputs/ 아래에 PNG로 자동 저장한다.
"""

from __future__ import annotations

import argparse
import base64
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional, Sequence


SCRIPT_DIR = Path(__file__).resolve().parent
BASE_IMAGE_PATH = SCRIPT_DIR / "input" / "base.png"
OUTPUT_DIR = SCRIPT_DIR / "outputs"
MODEL = "gpt-image-2"


# 이 문자열만 수정하면 모든 생성 요청에 적용되는 캐릭터 프리셋을 바꿀 수 있다.
CHARACTER_STYLE_PRESET = """
[캐릭터 정체성 프리셋 — 모든 사용자 요청과 모드보다 우선]
참조 이미지 속 바로 그 병아리의 변주여야 한다. 새 캐릭터, 다른 종족 또는 사람형 캐릭터를 발명하지 않는다.

[LOCKED — 절대 변경 금지]
- 둥글고 통통한 흰 몸통의 원본 실루엣과 기본 비율을 그대로 유지한다.
- 머리 위 한 가닥 컬의 위치, 크기, 감긴 방향과 형태를 그대로 유지한다.
- 작은 검은 눈, 작은 노란 부리, 부드러운 분홍 볼의 위치와 상대 비율을 그대로 유지한다.
- 노란 발의 짧고 둥글며 말랑한 원본 형태를 유지한다.
- 갈색 날개와 갈색 꼬리 포인트의 정체성과 기본 형태를 유지한다.
- 굵고 깨끗한 검은 외곽선과 납작한 2D 플랫 카툰/벡터 질감을 유지한다.

[VARIABLE — 요청에 따라 변경 가능]
- 의상과 소품
- 얼굴의 고정 위치와 비율을 훼손하지 않는 범위의 표정
- 배경, 장면 분위기와 조명
- 흰 몸통 정체성이 유지되는 범위의 아주 약한 피부 색감 변화
- 선택한 모드의 허용 범위 안에서 날개, 발과 몸통 기울기로 표현하는 포즈

[OUTFIT RULES — 의상이 있는 모든 요청에 강제 적용]
- 의상은 몸통 위에 겹쳐 입힌 별도의 의복 레이어로 보여야 한다.
- 몸통 자체의 색을 바꾸거나 몸통을 색칠하는 방식으로 의상을 표현하지 않는다.
- 의상이 덮지 않는 영역에서는 원본의 흰 몸통 색을 그대로 보존한다.
- 의상에는 옷임을 명확히 읽을 수 있는 경계, 스트랩, 봉제선, 단 또는 허리선 디테일이 있어야 한다.
- 의상은 둥근 마스코트 몸통에 자연스럽게 맞아야 하며 원본 몸통 실루엣을 바꾸지 않는다.
- 의상을 맞추기 위해 몸을 사람 체형으로 바꾸거나 인간형 신체 구조를 추가하지 않는다.

[FORBIDDEN — 절대 금지, 이미지에 생성하지 말 것]
- 사람 다리, 사람 팔, 손, 손가락 또는 관절이 드러나는 인간형 팔다리를 절대로 추가하지 않는다.
- 긴 팔다리, 사람 체형, 근육이나 골격이 보이는 해부학적 몸으로 바꾸지 않는다.
- 노란 발, 분홍 볼, 머리 컬, 갈색 날개 또는 갈색 꼬리를 삭제하거나 다른 요소로 대체하지 않는다.
- 의상을 몸통 전체를 단색으로 칠한 것처럼 처리하지 않는다. 의상은 몸통 위에 입은 별도 옷의 경계와 구조가 명확해야 한다.
- 사진 같은 실사 질감, 털 디테일, 3D 렌더 또는 피규어 질감으로 바꾸지 않는다.
- 검은 외곽선을 흐리게 하거나 제거하지 않는다.
- 몸통을 찌그러지거나 녹아내린 무정형 블롭으로 변형하지 않는다.
- 캐릭터 종족 변경, 얼굴 또는 신체의 전면 재설계, 사용자 요청에 없는 문자·워터마크·추가 캐릭터를 허용하지 않는다.

[충돌 처리 — 강제 우선순위]
- LOCKED와 FORBIDDEN은 strict, balanced, pose, creative를 포함한 모든 모드에 예외 없이 적용한다.
- 사용자 요청이나 모드 지침이 LOCKED 또는 FORBIDDEN과 충돌하면 충돌 부분을 무시하고 캐릭터 정체성 보존을 선택한다.
- creative 모드는 배경과 장면 연출의 자유도만 높이며 LOCKED 특징이나 FORBIDDEN 제한을 완화하지 않는다.
""".strip()


MODE_INSTRUCTIONS: Dict[str, str] = {
    "strict": """
[모드: strict]
- 원본의 포즈, 몸통 실루엣, 신체 비율, 얼굴 배치와 구도를 최대한 그대로 유지한다.
- 요청한 의상, 소품과 최소한의 표정 변화만 적용한다.
- 의상은 몸통 위치와 크기에 정확히 맞추고 의도한 신체 영역을 온전히 덮는다.
""".strip(),
    "balanced": """
[모드: balanced]
- 캐릭터 정체성과 핵심 비율을 확실히 유지한다.
- 요청에 필요한 범위에서 표정, 포즈, 배경과 장면 분위기를 자연스럽게 변경할 수 있다.
- 포즈는 날개, 짧은 발과 둥근 몸통의 기울기로만 표현하고 인간형 팔다리를 만들지 않는다.
- 변경 후에도 첫눈에 참조 이미지와 같은 병아리로 보여야 한다.
""".strip(),
    "creative": """
[모드: creative]
- 핵심 얼굴 특징, 컬, 색상 포인트, 외곽선과 병아리 정체성은 유지한다.
- 캐릭터가 명확히 알아볼 수 있는 범위에서 포즈, 배경, 구도와 장면을 자유롭게 연출한다.
- 자유도는 장면 연출에만 적용하며 LOCKED와 FORBIDDEN 규칙은 다른 모드와 동일하게 유지한다.
- 자유로운 연출이 인간형 팔다리, 종족 변경이나 완전히 새로운 캐릭터 디자인으로 이어져서는 안 된다.
""".strip(),
    "pose": """
[모드: pose]
- 캐릭터 정체성, 얼굴 특징, 색상과 그림체를 유지하면서 사용자 요청의 동작을 명확하게 표현한다.
- 동작은 기존 갈색 날개, 짧고 둥근 노란 발, 몸통의 기울기와 전체 위치 변화로 표현한다.
- 사람 팔, 사람 다리, 손가락 또는 길어진 팔다리를 새로 만들지 않는다.
- 동적인 포즈 때문에 다른 종족이나 새로운 캐릭터처럼 보이지 않도록 한다.
""".strip(),
}


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="input/base.png를 기준으로 자연어 캐릭터 변형 이미지를 생성합니다."
    )
    parser.add_argument("request", help="만들고 싶은 캐릭터 버전을 자연어로 입력하세요.")
    parser.add_argument(
        "--mode",
        choices=tuple(MODE_INSTRUCTIONS),
        default="balanced",
        help="변형 강도: strict, balanced(기본값), creative, pose",
    )
    parser.add_argument(
        "--character-only",
        action="store_true",
        help="장면 요소 없이 캐릭터만 단순한 배경에 배치합니다.",
    )
    parser.add_argument(
        "--print-prompt",
        action="store_true",
        help="API 호출 전에 조합된 최종 프롬프트를 출력합니다.",
    )
    return parser.parse_args(argv)


def build_prompt(user_request: str, mode: str, character_only: bool = False) -> str:
    request = user_request.strip()
    if not request:
        raise ValueError("자연어 요청이 비어 있습니다.")

    composition_rule = (
        "- 캐릭터만 단독으로 배치하고 배경 장면, 주변 사물과 추가 캐릭터를 넣지 않는다.\n"
        "- 단순한 흰색 배경을 사용한다."
        if character_only
        else "- 사용자가 배경을 지정하지 않으면 단순하고 방해되지 않는 배경을 사용한다."
    )

    return f"""
참조 이미지 input/base.png를 유일한 캐릭터 원본이자 가장 중요한 기준으로 사용한다.
아래 우선순위를 지켜 참조 이미지를 직접 편집한다.

우선순위:
1. 캐릭터 정체성 보존
2. 선택한 모드의 변경 범위 준수
3. 사용자 컨셉의 명확한 표현

{CHARACTER_STYLE_PRESET}

{MODE_INSTRUCTIONS[mode]}

[사용자 요청]
{request}

[출력 요구]
- 완성된 단일 캐릭터 이미지
- 정사각형 1:1 구도
- 캐릭터 전체가 잘리지 않도록 배치
{composition_rule}
""".strip()


def safe_output_path(user_request: str, mode: str) -> Path:
    """요청 속 ASCII 단어와 timestamp로 충돌 없는 안전한 파일명을 만든다."""
    ascii_words = re.findall(r"[A-Za-z0-9]+", user_request.lower())
    slug = "-".join(ascii_words[:6])[:48].strip("-") or "character"
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    return OUTPUT_DIR / f"{slug}-{mode}-{timestamp}.png"


def create_client():
    if not os.environ.get("OPENAI_API_KEY"):
        raise RuntimeError(
            "OPENAI_API_KEY가 설정되지 않았습니다. "
            "터미널에서 export OPENAI_API_KEY=\"...\" 를 먼저 실행하세요."
        )

    try:
        from openai import OpenAI
    except ImportError as exc:
        raise RuntimeError(
            "OpenAI Python SDK가 없습니다. "
            "python -m pip install --upgrade openai 를 실행하세요."
        ) from exc

    return OpenAI()


def generate_image(prompt: str, output_path: Path) -> None:
    if not BASE_IMAGE_PATH.is_file():
        raise FileNotFoundError(
            f"기준 이미지가 없습니다: {BASE_IMAGE_PATH}\n"
            "input/base.png 경로에 기준 캐릭터 PNG를 넣어주세요."
        )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    client = create_client()

    # Image Edit API에 기준 PNG를 직접 전달한다. gpt-image-2는 입력 이미지를
    # 자동으로 high-fidelity 처리하므로 input_fidelity 옵션을 별도로 넣지 않는다.
    with BASE_IMAGE_PATH.open("rb") as base_image:
        result = client.images.edit(
            model=MODEL,
            image=base_image,
            prompt=prompt,
            size="1024x1024",
            quality="high",
        )

    if not result.data or not result.data[0].b64_json:
        raise RuntimeError("API 응답에 이미지 데이터가 없습니다.")

    image_bytes = base64.b64decode(result.data[0].b64_json, validate=True)
    temporary_path = output_path.with_suffix(".tmp")
    temporary_path.write_bytes(image_bytes)
    temporary_path.replace(output_path)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)

    try:
        prompt = build_prompt(args.request, args.mode, args.character_only)
        if args.print_prompt:
            print("--- 최종 프롬프트 ---")
            print(prompt)
            print("---------------------")

        output_path = safe_output_path(args.request, args.mode)
        print(f"생성 중... (mode={args.mode}, model={MODEL})")
        generate_image(prompt, output_path)
        print(f"완료: {output_path}")
        return 0
    except (ValueError, FileNotFoundError, RuntimeError) as exc:
        print(f"오류: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        # SDK의 인증, 네트워크, 사용량 제한 오류도 비밀정보 없이 간결하게 표시한다.
        print(f"OpenAI API 호출 실패: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
