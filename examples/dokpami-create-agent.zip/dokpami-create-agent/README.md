# Character Variation Generator

Base character image를 기준으로 자연어 프롬프트를 입력해 다양한 캐릭터 변주 이미지를 생성하는 Python CLI 도구입니다.

## 준비

```bash
python -m pip install -r requirements.txt
```

캐릭터 원본과 API 키는 GitHub에 올리지 않고 각자 로컬에서 준비합니다.

1. 캐릭터 원본 PNG를 `input/base.png`에 넣습니다.
2. API 키를 코드에 적지 말고 환경변수로 설정합니다.

```bash
export OPENAI_API_KEY="your-api-key"
```

`outputs/` 폴더는 실행 시 자동 생성되며 GitHub에는 올라가지 않습니다. 승인된 레퍼런스 이미지는 필요할 경우 `input/refs/`에서 로컬로만 관리합니다.

## 실행

```bash
python generate.py "분홍 비키니 입고 해변에서 윙크하는 버전" --mode balanced
python generate.py "귀여운 좀비 버전, 회녹색 피부, 스티치, 다크서클 살짝" --mode strict
python generate.py "점프하면서 윙크하는 포즈" --mode pose --character-only
```

지원 모드:

- `strict`: 원본 포즈와 몸통을 최대한 유지
- `balanced`: 정체성을 유지하며 표정, 포즈와 배경을 적당히 변경
- `creative`: 알아볼 수 있는 범위에서 장면과 포즈를 자유롭게 변경
- `pose`: 캐릭터 정체성을 유지하며 요청한 동작을 강조

생성된 PNG는 `outputs/`에 안전한 파일명과 timestamp를 붙여 저장합니다.
